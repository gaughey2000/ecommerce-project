const multer = require('multer');
const path = require('path');
const pool = require('../db');

// Allowed types & size limit
const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
const maxSize = 2 * 1024 * 1024; // 2MB


const uploadsDir = path.join(__dirname, '..', 'uploads');  // one level up from controllers/
const storage = multer.diskStorage({
  destination: uploadsDir,
  filename: (req, file, cb) => { /* … */ }
});

const fileFilter = (req, file, cb) => {
  if (!allowedTypes.includes(file.mimetype)) {
    cb(new Error('Only image files are allowed (.jpg, .jpeg, .png, .webp)'));
  } else {
    cb(null, true);
  }
};

const multerUpload = multer({
  storage,
  limits: { fileSize: maxSize },
  fileFilter
});

// --- PROFILE IMAGE HANDLER ---
async function uploadProfileImage(req, res, next) {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image file received' });

    const userId = req.user?.userId;
    if (!userId) return res.status(401).json({ error: 'Unauthorized' });

    const imagePath = `/uploads/${req.file.filename}`;

    const { rowCount } = await pool.query(
      'UPDATE users SET profile_image = $1 WHERE user_id = $2',
      [imagePath, userId]
    );
    if (rowCount === 0) return res.status(404).json({ error: 'User not found' });

    // Keep response simple; your GET /api/users/me will return the absolute URL
    res.json({ image: imagePath, message: 'Profile image updated.' });
  } catch (err) {
    next(err);
  }
}

// --- PRODUCT IMAGE HANDLER ---
async function uploadProductImage(req, res, next) {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image file received' });

    const productId = req.body?.productId || req.query?.productId;
    if (!productId) return res.status(400).json({ error: 'Missing productId' });

    const imagePath = `/uploads/${req.file.filename}`;

    const { rowCount } = await pool.query(
      'UPDATE products SET image = $1 WHERE id = $2',
      [imagePath, productId]
    );
    if (rowCount === 0) return res.status(404).json({ error: 'Product not found' });

    res.json({ image: imagePath, message: 'Product image updated.' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  multerUpload,
  uploadProfileImage,
  uploadProductImage
};