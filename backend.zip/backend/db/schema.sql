-- ENUM
CREATE TYPE order_status AS ENUM ('pending','paid','shipped','delivered','cancelled');

-- orders table (includes shipping + stripe columns)
CREATE TABLE orders (
  order_id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  status order_status NOT NULL DEFAULT 'pending',
  total_amount NUMERIC(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  name VARCHAR(255),
  email VARCHAR(255),
  address TEXT,
  stripe_session_id TEXT,
  stripe_payment_intent TEXT
);

CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_session_id ON orders(stripe_session_id);
CREATE INDEX idx_orders_user_status ON orders(user_id, status);