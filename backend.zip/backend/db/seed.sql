-- Seed users
INSERT INTO users (username, email, password, is_admin) VALUES
  ('alice', 'alice@example.com', 'password123', FALSE),
  ('bob', 'bob@example.com', 'password456', FALSE),
  ('admin', 'admin@example.com', 'adminpassword', TRUE);

-- Seed products
INSERT INTO products (name, description, price, stock_quantity) VALUES
  ('Vintage T-shirt', 'Soft cotton vintage t-shirt', 19.99, 100),
  ('Enamel Mug', 'Handmade enamel camping mug', 9.99, 200),
  ('Wool Socks', 'Warm wool socks, perfect for winter', 12.50, 150);

-- Seed categories
INSERT INTO product_categories (product_id, category_name) VALUES
  (1, 'Clothing'),
  (2, 'Kitchen'),
  (3, 'Clothing');

-- Seed cart items
INSERT INTO cart_items (user_id, product_id, quantity) VALUES
  (1, 1, 2),
  (1, 2, 1),
  (2, 3, 3);

-- Seed orders
INSERT INTO orders (user_id, status, total_amount) VALUES
  (1, 'pending', 49.97),
  (2, 'shipped', 37.50);

-- Seed order items
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
  (1, 1, 2, 19.99),
  (1, 2, 1, 9.99),
  (2, 3, 3, 12.50);
